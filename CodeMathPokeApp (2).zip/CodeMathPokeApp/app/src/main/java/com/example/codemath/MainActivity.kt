package com.example.codemath

import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.loopj.android.http.AsyncHttpClient
import com.loopj.android.http.JsonHttpResponseHandler
import com.squareup.picasso.Picasso
import cz.msebera.android.httpclient.Header
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private lateinit var nameText: TextView
    private lateinit var typeText: TextView
    private lateinit var weightText: TextView
    private lateinit var imageView: ImageView
    private lateinit var nextButton: Button

    private val client = AsyncHttpClient()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        nameText = findViewById(R.id.pokemon_name)
        typeText = findViewById(R.id.pokemon_type)
        weightText = findViewById(R.id.pokemon_weight)
        imageView = findViewById(R.id.pokemon_image)
        nextButton = findViewById(R.id.button_next)

        // Initial load
        fetchRandomPokemon()

        nextButton.setOnClickListener {
            fetchRandomPokemon()
        }
    }

    private fun fetchRandomPokemon() {
        // Original example: Ditto (132). We'll randomize between 1 and 151 (Gen 1).
        val id = (1..151).random()
        val url = "https://pokeapi.co/api/v2/pokemon/$id"

        client.get(url, object : JsonHttpResponseHandler() {
            override fun onSuccess(
                statusCode: Int,
                headers: Array<Header>?,
                response: JSONObject?
            ) {
                if (response == null) return

                val name = response.optString("name", "unknown")
                val typesArray = response.optJSONArray("types")
                val firstTypeObj = typesArray?.optJSONObject(0)
                val type = firstTypeObj
                    ?.optJSONObject("type")
                    ?.optString("name", "unknown") ?: "unknown"

                val weight = response.optInt("weight", 0)
                val sprites = response.optJSONObject("sprites")
                val imageUrl = sprites?.optString("front_default", "")

                nameText.text = "Name: ${name.capitalize()}"
                typeText.text = "Type: $type"
                weightText.text = "Weight: $weight"

                if (!imageUrl.isNullOrEmpty()) {
                    Picasso.get()
                        .load(imageUrl)
                        .fit()
                        .centerInside()
                        .into(imageView)
                } else {
                    imageView.setImageResource(R.drawable.ic_pokeball)
                }
            }

            override fun onFailure(
                statusCode: Int,
                headers: Array<Header>?,
                throwable: Throwable?,
                errorResponse: JSONObject?
            ) {
                nameText.text = "Error loading Pokémon"
                typeText.text = ""
                weightText.text = ""
                imageView.setImageResource(R.drawable.ic_pokeball)
            }
        })
    }
}
